
public class ProdutoA {
	public int id;
    public  String nome;
    public String descricao;
    public int quantidade;
    public double preco;
    
    public ProdutoA(){
        this.id = 0;
        this.nome = " ";
        this.descricao = " ";
        this.quantidade = 0;
        this.preco = 0;
    }
}
